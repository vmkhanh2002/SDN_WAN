"""FastMCP package

Exports the application instance for uvicorn: `fastmcp.app:app`
"""

from .app import app

__all__ = ["app"]
